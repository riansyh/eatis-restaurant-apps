import "regenerator-runtime"; /* for async await transpile */
import "../styles/style.scss";
import "./hamburger";
import "./restaurant";
