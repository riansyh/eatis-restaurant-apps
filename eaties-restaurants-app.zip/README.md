# eatis-restaurant-apps

This repository is a submission for Front-end Web Expert Course, Dicoding.

## Usage

1. Install NPM packages

   ```sh
   npm install

   ```

2. Run the website

   ```sh
   # Development mode
   npm run start-dev

   # Production mode
   npm run build
   ```

## Live Site URL

https://eatis-restaurant-apps.vercel.app/
